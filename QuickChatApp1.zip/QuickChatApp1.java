/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp1;
import java.util.Scanner;
/**
 *
 * @author ST10538985-Bokang Mokola
 */
public class QuickChatApp1 {

    public static   void  main(String[] args) {
       
          //Create an object for the Scanner class
     Scanner input = new Scanner(System.in);
     
     //login object to allow user input
     Login login = new Login
     
     //Declaring variables to store user details 
     String firstName, lastName, username, password , cellphone number ;
     
     
     //ask user to enter their details
     System.out.print("Please enter your username: ");
     username = input.nextLine();
     //Validate
     if (login.checkUsername(username)){
         System.out.print("Usernamesuccessfully captured");
     }else{
         System.out.println("Username incorrectly formatted. Please ensure that your username contains an underscore and is not more than five charactersin length.");
     }
     
System.out.print("Please enter your password: ");
     password = input.nextLine();
     //Validate
     if (login.checkPassword(password)){
         System.out.print("Password successfully captured");
     }else{
         System.out.println("Password is not correctly formatted. Please ensure that yhe password contains atleast eight characters,a capital letter , a number and a special character.");
     }
     
    System.out.print("Please enter your cellphone number: ");
     cellphoneNumber = input.nextLine();
     {
      
     }
     
     //Validate
     if(login.checkCellphoneNumber(cellphone number )){
         Systems.out.print("Cellphone number successfully added");
     }else{
         System.out.println("Cellphone number incorrectly formatted or does not contain international code.");
     }
    }
}
//display the registration status 
System .out.printin(login.registerUser(firstName,lastName,userName,password,cellphoneNumb)):

//declare temporary variables to allow user to login 
String loginUsername. loginPassword :

System.out.printLn("\n****************LOGIN*********************");

Sytem.out.print("Please enter your login username:");
loginUsername = input.nextLine();

System.out.print("Please enter your login username:");
loginUsername = input.nextLine();

System.not.println("returnLoginStatus(firstname)");
